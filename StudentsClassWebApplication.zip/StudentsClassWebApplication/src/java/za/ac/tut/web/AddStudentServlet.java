/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Collection;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.ejb.EJB;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
import za.ac.tut.ejb.bl.StudentFacadeLocal;
import za.ac.tut.entities.Image;
import za.ac.tut.entities.Student;

/**
 *
 * @author Student
 */
@MultipartConfig
public class AddStudentServlet extends HttpServlet {
    @EJB
    private StudentFacadeLocal sfl;
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Long studentNumber = Long.parseLong(request.getParameter("studnr"));
        String name = request.getParameter("name");
        String surname = request.getParameter("surname");
        Date creationDate = new Date();
        Image image = null;
        
        Collection<Part> parts = request.getParts();
        
        for(Part part: parts){
            if(part.getContentType()!= null){
                InputStream imagePart = part.getInputStream();
                byte[] imageSource = convertImageToByte(imagePart);
                image = new Image(imageSource);
            }
        }
        
        Student stud = new Student(studentNumber, name, surname, image, creationDate);
        sfl.create(stud);
        
        request.setAttribute("studnr", studentNumber);
        request.setAttribute("surname", surname);
        RequestDispatcher disp = request.getRequestDispatcher("Student_added_outcome.jsp");
        disp.forward(request, response);
    }

    private byte[] convertImageToByte(InputStream imagePart) {
          
        byte[] imageBLOB = null;
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        byte[] buffer = new byte[1024];
        Integer buffer_integer = 0;
        
        try {
            while((buffer_integer = imagePart.read(buffer))!= -1){
                baos.write(buffer, 0, buffer_integer);
            }
            
            imageBLOB = baos.toByteArray();
        } catch (IOException ex) {
            Logger.getLogger(AddStudentServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return imageBLOB;
    }

}
